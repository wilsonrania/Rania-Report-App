# Rania Report Android app

This Android WebView wrapper loads https://raniareport.blogspot.com/ and includes:
- JavaScript enabled WebView and DOM storage
- Native Android Print Framework bridge for `window.print()`
- DownloadManager support for normal PDF/Excel downloads, preserving cookies
- Blob URL download bridge for JavaScript-generated files
- Back navigation and file chooser support
- Your exact supplied Rania Report logo configured as the Android launcher icon (multiple screen densities)
- The same supplied logo shown on the startup splash screen while the website loads

## Build APK using GitHub
1. Create a new GitHub repository.
2. Upload all files from this project (including the `.github` folder).
3. Open **Actions** and run **Build Rania Report APK**, or push to `main`.
4. Open the completed workflow run and download artifact `RaniaReport-debug-apk`.
5. Extract it; install `app-debug.apk` on your Android phone.

## Important testing note
The app provides native print/download handling, but actual results depend on how the Blogger page implements its Print/PDF/Excel buttons. Test each button on a device after building. Some sites generate Excel/PDF through cross-origin scripts or server endpoints; those may need a page-specific JavaScript integration.

This is a debug APK build for testing, not a Play Store release-signed APK.
