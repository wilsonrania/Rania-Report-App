package com.raniareport.app;

import android.app.Activity;
import android.app.DownloadManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.print.PrintAttributes;
import android.print.PrintManager;
import android.provider.MediaStore;
import android.webkit.CookieManager;
import android.webkit.DownloadListener;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.view.View;
import android.view.Gravity;
import android.graphics.Color;
import android.util.Base64;
import android.content.ContentValues;
import java.io.OutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.net.URLDecoder;

public class MainActivity extends Activity {
    private WebView webView;
    private ImageView splashView;
    private FrameLayout rootLayout;
    private ValueCallback<Uri[]> filePathCallback;
    private static final int FILE_CHOOSER_REQUEST = 1001;
    private static final String HOME = "https://raniareport.blogspot.com/";

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        rootLayout = new FrameLayout(this);
        webView = new WebView(this);
        rootLayout.addView(webView, new FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));

        // Use the exact logo supplied by the user as the app startup splash.
        splashView = new ImageView(this);
        splashView.setImageResource(R.drawable.rania_report_logo);
        splashView.setScaleType(ImageView.ScaleType.FIT_CENTER);
        splashView.setBackgroundColor(Color.WHITE);
        splashView.setPadding(28, 28, 28, 28);
        FrameLayout.LayoutParams splashParams = new FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT);
        splashParams.gravity = Gravity.CENTER;
        rootLayout.addView(splashView, splashParams);
        setContentView(rootLayout);
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.getSettings().setAllowFileAccess(false);
        webView.getSettings().setJavaScriptCanOpenWindowsAutomatically(true);
        webView.getSettings().setSupportMultipleWindows(true);
        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(webView, true);
        webView.addJavascriptInterface(new Bridge(), "AndroidBridge");

        webView.setWebViewClient(new WebViewClient() {
            @Override public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                injectPrintAndBlobSupport();
                if (splashView != null) splashView.setVisibility(View.GONE);
            }
            @Override public void onReceivedError(WebView view, WebResourceRequest request,
                                                   android.webkit.WebResourceError error) {
                super.onReceivedError(view, request, error);
                if (request.isForMainFrame() && splashView != null) splashView.setVisibility(View.GONE);
            }
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                String scheme = uri.getScheme() == null ? "" : uri.getScheme();
                if (!scheme.equals("http") && !scheme.equals("https")) {
                    try { startActivity(new Intent(Intent.ACTION_VIEW, uri)); } catch (Exception ignored) {}
                    return true;
                }
                return false;
            }
        });
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (filePathCallback != null) filePathCallback.onReceiveValue(null);
                filePathCallback = callback;
                Intent intent = params.createIntent();
                try { startActivityForResult(intent, FILE_CHOOSER_REQUEST); }
                catch (Exception e) { filePathCallback = null; return false; }
                return true;
            }
        });
        webView.setDownloadListener(new DownloadListener() {
            @Override public void onDownloadStart(String url, String userAgent, String contentDisposition,
                                                   String mimetype, long contentLength) {
                try {
                    if (url != null && url.startsWith("blob:")) {
                        String safeMime = mimetype == null ? "" : mimetype;
                        String jsUrl = org.json.JSONObject.quote(url);
                        String jsMime = org.json.JSONObject.quote(safeMime);
                        String js = "(function(){var u=" + jsUrl + ";var m=" + jsMime + ";"
                            + "var a=Array.from(document.querySelectorAll('a')).find(x=>x.href===u);"
                            + "var n=a&&a.download?a.download:(m.indexOf('pdf')>=0?'Rania-Report.pdf':"
                            + "(m.indexOf('sheet')>=0||m.indexOf('excel')>=0?'Rania-Report.xlsx':'Rania-Report-download'));"
                            + "fetch(u).then(r=>r.blob()).then(b=>{var f=new FileReader();"
                            + "f.onloadend=function(){AndroidBridge.saveBase64File(f.result.split(',')[1],n);};"
                            + "f.readAsDataURL(b);}).catch(e=>AndroidBridge.downloadError(String(e)));})();";
                        webView.evaluateJavascript(js, null);
                        return;
                    }
                    String filename = android.webkit.URLUtil.guessFileName(url, contentDisposition, mimetype);
                    DownloadManager.Request request = new DownloadManager.Request(Uri.parse(url));
                    request.setTitle(filename);
                    request.setDescription("Downloading from Rania Report");
                    request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
                    request.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, filename);
                    request.addRequestHeader("User-Agent", userAgent);
                    String cookies = CookieManager.getInstance().getCookie(url);
                    if (cookies != null) request.addRequestHeader("Cookie", cookies);
                    request.setMimeType(mimetype);
                    ((DownloadManager)getSystemService(DOWNLOAD_SERVICE)).enqueue(request);
                    Toast.makeText(MainActivity.this, "Download started", Toast.LENGTH_SHORT).show();
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this, "Download failed: " + e.getMessage(), Toast.LENGTH_LONG).show();
                }
            }
        });
        if (savedInstanceState != null) webView.restoreState(savedInstanceState);
        else webView.loadUrl(HOME);
    }

    private void injectPrintAndBlobSupport() {
        String js = "(function(){"
          + "if(window.__rrNativeReady)return;window.__rrNativeReady=true;"
          + "window.print=function(){AndroidBridge.printPage();};"
          + "document.addEventListener('click',function(e){"
          + "var a=e.target.closest&&e.target.closest('a[href^=\"blob:\"]');if(!a)return;"
          + "e.preventDefault();fetch(a.href).then(r=>r.blob()).then(b=>{"
          + "var fr=new FileReader();fr.onloadend=function(){AndroidBridge.saveBase64File(fr.result.split(',')[1],a.download||'download');};fr.readAsDataURL(b);"
          + "}).catch(()=>{});},true);"
          + "})();";
        webView.evaluateJavascript(js, null);
    }

    private void createPrintJob() {
        try {
            PrintManager pm = (PrintManager)getSystemService(Context.PRINT_SERVICE);
            String jobName = "Rania Report";
            pm.print(jobName, webView.createPrintDocumentAdapter(jobName), new PrintAttributes.Builder().build());
        } catch (Exception e) {
            Toast.makeText(this, "Print could not be opened", Toast.LENGTH_LONG).show();
        }
    }

    private void saveBase64(String base64, String filename) {
        try {
            byte[] bytes = Base64.decode(base64, Base64.DEFAULT);
            String safeName = filename.replaceAll("[^a-zA-Z0-9._-]", "_");
            if (Build.VERSION.SDK_INT >= 29) {
                String mime = safeName.toLowerCase().endsWith(".pdf") ? "application/pdf" :
                    (safeName.toLowerCase().endsWith(".xls") || safeName.toLowerCase().endsWith(".xlsx")
                    ? "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" : "application/octet-stream");
                ContentValues values = new ContentValues();
                values.put(MediaStore.Downloads.DISPLAY_NAME, safeName);
                values.put(MediaStore.Downloads.MIME_TYPE, mime);
                values.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);
                Uri uri = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
                if (uri == null) throw new Exception("Cannot create download");
                OutputStream out = getContentResolver().openOutputStream(uri);
                if (out == null) throw new Exception("Cannot open download file");
                out.write(bytes); out.close();
            } else {
                File dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
                if (!dir.exists()) dir.mkdirs();
                FileOutputStream out = new FileOutputStream(new File(dir, safeName));
                out.write(bytes); out.close();
            }
            runOnUiThread(() -> Toast.makeText(this, "Saved in Downloads", Toast.LENGTH_LONG).show());
        } catch (Exception e) {
            runOnUiThread(() -> Toast.makeText(this, "Save failed", Toast.LENGTH_LONG).show());
        }
    }

    private class Bridge {
        @JavascriptInterface public void printPage() { runOnUiThread(() -> createPrintJob()); }
        @JavascriptInterface public void saveBase64File(String data, String filename) {
            saveBase64(data, filename);
        }
        @JavascriptInterface public void downloadError(String message) {
            runOnUiThread(() -> Toast.makeText(MainActivity.this, "Download failed: " + message, Toast.LENGTH_LONG).show());
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == FILE_CHOOSER_REQUEST && filePathCallback != null) {
            Uri[] results = WebChromeClient.FileChooserParams.parseResult(resultCode, data);
            filePathCallback.onReceiveValue(results);
            filePathCallback = null;
        }
    }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }

    @Override protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        if (webView != null) webView.saveState(outState);
    }

    @Override protected void onDestroy() {
        if (webView != null) { webView.destroy(); webView = null; }
        if (rootLayout != null) { rootLayout.removeAllViews(); rootLayout = null; }
        splashView = null;
        super.onDestroy();
    }
}
